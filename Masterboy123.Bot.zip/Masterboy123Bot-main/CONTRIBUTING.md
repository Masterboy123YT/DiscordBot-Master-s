# Contribution Rules

- The code should be matched with this repository.

- The code that you are prividing should not contain other packages.

- The code should be neat and clean in segments.

- The code should make sense like changing something in `readme.md` will not be accepted.

- You must be in our discord server join us by [clicking here](https://discord.com/invite/fF5qMqhKQ3)

- [![DiscordBanner](https://cdn.discordapp.com/attachments/1267758680367956032/1269654997583532032/standard.gif?ex=66b0d9dc&is=66af885c&hm=4f0c36eebd0ea378f6871fc215b2cadfa26e2f83816c74c402161ed6c4c518d5&)](https://discord.com/invite/fF5qMqhKQ3)
