module.exports = async(client, info) => {

    console.log(`Debug -> ${info}`)
    
}